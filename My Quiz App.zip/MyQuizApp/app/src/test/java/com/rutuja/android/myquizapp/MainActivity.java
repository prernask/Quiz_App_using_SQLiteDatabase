package com.rutuja.android.myquizapp;

public class MainActivity {
}
