package com.rutuja.android.myquizapp;

public class Constants {
    public static final String PROGRAMMING = "Programming";
    public static final String PYTHON = "Python";
    public static final String JAVA = "Java";
    public static final String DBMS = "Dbms";
    public static final String DATA_STRUCTURES = "Data_structures";
    public static final String MACHINE_LEARNING = "Machine_learning";
    public static final String CLOUD_COMPUTING = "Cloud_computing";
    public static final String CYBER_SECURITY = "Cyber_security";
}
